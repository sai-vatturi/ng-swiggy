export interface feature{
    img:string,
    alt:string,
    title:string
}
export interface section4{
    img:string,
    alt:string,
    para:string,
    title:string
}
export interface footer{
    Company:string[],
    Explore:string[],
    Insurance:string[]
}