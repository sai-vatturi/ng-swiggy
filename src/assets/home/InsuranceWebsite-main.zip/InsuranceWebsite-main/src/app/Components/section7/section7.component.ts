import { Component } from '@angular/core';

@Component({
  selector: 'app-section7',
  standalone: true,
  imports: [],
  templateUrl: './section7.component.html',
  styleUrl: './section7.component.css'
})
export class Section7Component {

}
